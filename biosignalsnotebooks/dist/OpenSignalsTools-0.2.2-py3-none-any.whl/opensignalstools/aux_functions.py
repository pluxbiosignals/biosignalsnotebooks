"""
Auxiliary functions used in multiples modules of opensignalstools package.
"""


def _is_instance(type_to_check, element, condition="any"):
    """
    Function that verifies when "all" or "any" elements of the list "element" of type specified
    in "type_to_check" input.

    ----------
    Parameters
    ----------
    type_to_check : type element
        Data type.

    element : list
        List where condition will be checked.

    condition : str
        String with values "any" or "all" verifying when "any" or "all" element entries have the
        specified type.

    Returns
    -------
    out : boolean
        Returns True when the condition is verified for the element list.
    """

    if condition == "any":
        out = any(isinstance(el, type_to_check) for el in element)
    elif condition == "all":
        out = all(isinstance(el, type_to_check) for el in element)

    return out

# 18/09/2018 13h34m :)
