"""
    File that contains the Python code to be executed in "group_by_tag" Notebook.
"""

TAG_TABLE_HEADER = """\
<table>
    <tr>
        <td colspan="3" class="group_by_header">
            Tag i
        </td>
    </tr>
"""

# 07/11/2018  00h02m :)