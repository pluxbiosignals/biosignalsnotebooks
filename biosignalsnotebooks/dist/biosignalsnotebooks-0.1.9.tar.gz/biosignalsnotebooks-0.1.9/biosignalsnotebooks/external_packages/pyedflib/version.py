
# THIS FILE IS GENERATED FROM pyedflib SETUP.PY
short_version = '0.1.12'
version = '0.1.12'
full_version = '0.1.12'
git_revision = '9d643b430cfe551a9eb01f71f7cbcddbea44c038'
release = True

if not release:
    version = full_version
