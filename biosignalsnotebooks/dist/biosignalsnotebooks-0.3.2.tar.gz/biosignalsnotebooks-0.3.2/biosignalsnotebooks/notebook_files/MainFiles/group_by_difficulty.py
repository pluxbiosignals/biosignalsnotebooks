"""
    File that contains the Python code to be executed in "group_by_difficulty" Notebook.
"""

STAR_TABLE_HEADER = """\
<table>
    <tr>
        <td colspan="3" class="group_by_header">
            <span class="fa fa-star 1"></span>
            <span class="fa fa-star 2"></span>
            <span class="fa fa-star 3"></span>
            <span class="fa fa-star 4"></span>
            <span class="fa fa-star 5"></span>
        </td>
    </tr>
"""

# 02/11/2018  17h33m :)