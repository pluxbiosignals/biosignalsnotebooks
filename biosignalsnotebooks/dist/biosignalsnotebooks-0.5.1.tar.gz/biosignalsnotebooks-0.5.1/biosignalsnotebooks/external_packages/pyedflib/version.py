
# THIS FILE IS GENERATED FROM pyedflib SETUP.PY
short_version = '0.1.14'
version = '0.1.14'
full_version = '0.1.14'
git_revision = 'Unknown'
release = True

if not release:
    version = full_version
