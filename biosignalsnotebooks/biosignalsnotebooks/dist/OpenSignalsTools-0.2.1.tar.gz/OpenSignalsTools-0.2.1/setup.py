"""
File that specifies package requisites for a correct functioning of all available functions.

"""

from setuptools import setup
from os import path

# read the contents of your README file
this_directory = path.abspath(path.dirname(__file__))
with open(path.join(this_directory, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()


setup(name='OpenSignalsTools',
      version='0.2.1',
      description='A Python package for supporting the external loading and processing of '
                  'OpenSignals electrophysiological acquisitions.',
      long_description=long_description,
      long_description_content_type='text/markdown',
      url='https://github.com/novabiosignals/opensignalstools',
      author='Plux Wireless Biosignals',
      author_email='gramos@plux.info',
      license='MIT',
      packages=['opensignalstools'],
      install_requires=[
          'h5py', 'pyedflib', 'python-magic', 'numpy', 'wget', 'datetime',
          'bokeh', 'scipy', 'IPython', 'pandas', 'novainstrumentation'
      ],
      zip_safe=False)

# 18/09/2018 13h34m :)
