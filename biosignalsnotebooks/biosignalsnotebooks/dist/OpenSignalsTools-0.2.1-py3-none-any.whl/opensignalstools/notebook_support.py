
"""
List of functions intended to support the Jupyter Notebooks, encapsulating code that the user should not access.
"""

from IPython.core.display import HTML

def cssStyleApply():
    """
        Function that apply the css configurations to the Jupyter Notebook pages.
    """

    style = open("styles/theme_style.css", "r").read()
    return HTML(style)