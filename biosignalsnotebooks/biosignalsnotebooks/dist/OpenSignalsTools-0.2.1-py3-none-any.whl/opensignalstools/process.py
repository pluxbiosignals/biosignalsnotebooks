
"""
List of functions intended to extract knowledge from the processing of data.

"""

import numpy
from .detect import tachogram


def poincare(data, sample_rate, signal=False, in_seconds=False):
    """
    Function for generation of Poincaré Plot (Heart rate variability analysis)

    ----------
    Parameters
    ----------
    data : list
        ECG signal or R peak list. When the input is a raw signal the input flag signal should be
        True.

    sample_rate : int
        Sampling frequency.

    signal : boolean
        If true, then the data argument contains the set of the ECG acquired samples.

    in_seconds : boolean
        If the R peaks list defined as the input argument "data" contains the sample numbers where
        the R peaks occur,
        then in_seconds needs to be True.

    Returns
    -------
    out : list, list, float, float
        Poincaré plot x axis and y axis, respectively. Additionally it will be returned SD1 and SD2
        parameters.

    """

    # Generation of tachogram.
    tachogram_data = tachogram(data, sample_rate, signal=signal, in_seconds=in_seconds,
                               out_seconds=True)[0]

    # Poincaré Plot (x and y axis).
    x_axis = tachogram_data[:-1]
    y_axis = tachogram_data[1:]

    # Poincaré Parameters.
    tachogram_diff = numpy.diff(tachogram_data)
    sdsd = numpy.std(tachogram_diff)
    sdnn = numpy.std(tachogram_data)

    sd1 = numpy.sqrt(0.5 * numpy.power(sdsd, 2))
    sd2 = numpy.sqrt(2 * numpy.power(sdnn, 2) - numpy.power(sd1, 2))

    return x_axis, y_axis, sd1, sd2

# 18/09/2018 13h34m :)
